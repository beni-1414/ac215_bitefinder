# Package initialization for inference module
