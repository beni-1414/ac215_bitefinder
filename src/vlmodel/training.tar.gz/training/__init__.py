# Package initialization for training module
